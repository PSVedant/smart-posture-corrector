# sitting posture > sitting_posture_4Keypoint
https://universe.roboflow.com/ikornproject/sitting-posture-rofqf

Provided by a Roboflow user
License: CC BY 4.0

